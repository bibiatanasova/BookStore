﻿using BookStore.Models;
using JetBrains.Annotations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace BookStore
{
    public class DataConnection:DbContext
    {
        private const string MySqlConnectionString = "Server = localhost; Database=book_store;Uid=root;Pwd=Bibicen3103.";

        public DataConnection()
        {
               
        }

        public DataConnection(DbContextOptions options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseMySQL(MySqlConnectionString);

            }
        }
        
        public DbSet<Author> Authors { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Seller> Sellers { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Sales> Sales { get; set; }
    }
}
