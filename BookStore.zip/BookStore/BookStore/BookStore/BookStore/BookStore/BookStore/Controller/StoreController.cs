﻿using BookStore.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookStore.Controller
{
    public class StoreController
    {
        //private BookOperation bookOperation;
        //private bool isRunning;

        //public StoreController(BookOperation bookOperation)
        //{
        //    this.bookOperation = bookOperation;
        //    this.isRunning = true;
        //}

        //public void GetAll()
        //{
        //    List<Book> books = this.bookOperation.GetAllBooks();

        //    foreach (var book in books)
        //    {
        //        Console.WriteLine(book);
        //    }
        //}

        //public void CreateBook()
        //{
        //    Console.WriteLine("Title:");
        //    string title = Console.ReadLine();
        //    Console.WriteLine("Autor:");
        //    string[] authorName = Console.ReadLine().Split(" ");
        //    Console.WriteLine("Genre:");
        //    string genre = Console.ReadLine();
        //    Console.WriteLine("Year:");
        //    int year = int.Parse(Console.ReadLine());
        //    Console.WriteLine("Price:");
        //    decimal price = decimal.Parse(Console.ReadLine());

        //    Book book = new Book(1, title, genre, year, price, 1, authorName[0], authorName[1]);
        //    this.bookOperation.CreateBook(book);
        //}

        //public void UpdateBook()
        //{
        //    Console.WriteLine("Book ID:");
        //    int idBook = int.Parse(Console.ReadLine());

        //    Console.WriteLine(this.bookOperation.GetBook(idBook));

        //    Console.WriteLine("Title:");
        //    string title = Console.ReadLine();
        //    Console.WriteLine("Autor first name:");
        //    string authorFirstName = Console.ReadLine();
        //    Console.WriteLine("Autor last name:");
        //    string autorLastName = Console.ReadLine();
        //    Console.WriteLine("Genre:");
        //    string genre = Console.ReadLine();
        //    Console.WriteLine("Year:");
        //    int year = int.Parse(Console.ReadLine());
        //    Console.WriteLine("Price:");
        //    decimal price = decimal.Parse(Console.ReadLine());

        //    Book book = new Book(idBook, title, genre, year, price, 0, authorFirstName, autorLastName);

        //    this.bookOperation.UpdateBook(book);
        //}

        //public void GetBook()
        //{
        //    Console.WriteLine("Book ID:");
        //    int id = int.Parse(Console.ReadLine());

        //    Book book = this.bookOperation.GetBook(id);

        //    Console.WriteLine(book);
        //}

        //public void DeleteBook()
        //{
        //    Console.WriteLine("Book ID:");
        //    int id = int.Parse(Console.ReadLine());

        //    this.bookOperation.DeleteBook(id);
        //}

    }
}   

