﻿using System;
using StoreController.Controller;
using Book.Models;

namespace DataConnection
{
    class Program
    {
        static void Main(string[] args)
        {
            Book book = new Book();
        }
    }
}
