﻿
using BookStore;
using BookStore.Controller;
using BookStore.Models;
using Microsoft.EntityFrameworkCore;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BookStoreTest
{
    public class BookOperationTest
    {
        private DataConnection dataConnection;

        [SetUp]
        public void Setup()
        {
            var options = new DbContextOptionsBuilder<DataConnection>()
                .UseInMemoryDatabase("test_book_store").Options;

            this.dataConnection = new DataConnection(options);
        }

        [TearDown]
        public void TearDown()
        {
            this.dataConnection.Database.EnsureDeleted();
        }


        [Test]
        public void CreateBookTest()
        {
            BookOperation bookOperation = new BookOperation(dataConnection);

            Author author = new Author(1, "J.K.", "Rowling");

            Book book = new Book(1, "Harry Potter Chamber of Secrets", "Fantasy", 1998, 19.90M, 1, 2);
            Book book1 = new Book(2, "Harry Potter Prisoner of Azkaban", "Fantasy", 1999, 19.90M, 1, 3);
            Book book2 = new Book(3, "Harry Potter Goblet of Fire", "Fantasy", 2000, 19.90M, 1, 3);

            bookOperation.CreateBook(book);
            bookOperation.CreateBook(book1);
            bookOperation.CreateBook(book2);

            Assert.AreEqual(3, this.dataConnection.Books.ToList().Count());

        }

        [Test]
        public void AddAuthorTest()
        {
            BookOperation bookOperation = new BookOperation(dataConnection);

            Author author = new Author(1, "J.K.", "Rowling");
            Author author1 = new Author(2, "Daniel", "Stan");

            bookOperation.AddAuthor(author);
            bookOperation.AddAuthor(author1);

            Assert.AreEqual(2, this.dataConnection.Authors.ToList().Count());
        }

        [Test]
        public void AddCustomerTest()
        {
            BookOperation bookOperation = new BookOperation(dataConnection);

            Customer customer = new Customer(1, "123", "Ivan", "Ivanov", 17);
            Customer customer2 = new Customer(2, "456d", "Ivaylo", "Yordanov", 20);

            bookOperation.AddCustomer(customer);
            bookOperation.AddCustomer(customer2);

            Assert.AreEqual(2, this.dataConnection.Customers.ToList().Count());
        }

        [Test]
        public void AddSellerTest()
        {
            BookOperation bookOperation = new BookOperation(dataConnection);

            Seller seller = new Seller(1, "Maria", "Angelova");
            Seller seller1 = new Seller(2, "Hristiyan", "Atanasov");

            bookOperation.AddSeller(seller);
            bookOperation.AddSeller(seller1);

            Assert.AreEqual(2, this.dataConnection.Sellers.ToList().Count());
        }

        [Test]
        public void DeleteCustomerTest()
        {
            BookOperation bookOperation = new BookOperation(dataConnection);

            Customer customer = new Customer(1, "fd56", "Ivet", "Angelova", 14);
            Customer customer1 = new Customer(2, "d68f", "Aida", "Marinova", 17);
            Customer customer2 = new Customer(3, "df88d", "Ina", "Georgieva", 18);

            bookOperation.AddCustomer(customer);
            bookOperation.AddCustomer(customer1);
            bookOperation.AddCustomer(customer2);

            bookOperation.DeleteCustomer(1);

            Assert.AreEqual(2, this.dataConnection.Customers.ToList().Count);
        }

        [Test]
        public void DeleteSellerTest()
        {
            BookOperation bookOperation = new BookOperation(dataConnection);

            Seller seller = new Seller(1, "Maria", "Angelova");
            Seller seller1 = new Seller(2, "Hristiyan", "Atanasov");
            Seller seller2 = new Seller(3, "Ivaylo", "Ivanov");

            bookOperation.AddSeller(seller);
            bookOperation.AddSeller(seller1);
            bookOperation.AddSeller(seller2);

            bookOperation.DeleteSeller(2);
            bookOperation.DeleteSeller(1);

            Assert.AreEqual(1, this.dataConnection.Sellers.ToList().Count());
        }

        [Test]
        public void DeleteAuthorTest()
        {

            BookOperation bookOperation = new BookOperation(dataConnection);

            Author author = new Author(1, "J.K.", "Rowling");
            Author author1 = new Author(2, "Daniel", "Stan");
            Author author2 = new Author(3, "Peter", "James");

            bookOperation.AddAuthor(author);
            bookOperation.AddAuthor(author1);
            bookOperation.AddAuthor(author2);

            bookOperation.DeleteAuthor(3);

            Assert.AreEqual(2, this.dataConnection.Authors.ToList().Count());
        }

        [Test]
        public void DeleteBookTest()
        {
            BookOperation bookOperation = new BookOperation(dataConnection);

            Author author = new Author(1, "J.K.", "Rowling");

            Book book = new Book(1, "Harry Potter Chamber of Secrets", "Fantasy", 1998, 19.90M, 1, 2);
            Book book1 = new Book(2, "Harry Potter Prisoner of Azkaban", "Fantasy", 1999, 19.90M, 1, 3);
            Book book2 = new Book(3, "Harry Potter Goblet of Fire", "Fantasy", 2000, 19.90M, 1, 3);

            bookOperation.CreateBook(book);
            bookOperation.CreateBook(book1);
            bookOperation.CreateBook(book2);

            bookOperation.DeleteBook(3);

            Assert.AreEqual(2, this.dataConnection.Books.ToList().Count());
        }

        [Test]
        public void SaleBookWithLeftoversTest()
        {
            BookOperation bookOperation = new BookOperation(dataConnection);

            Author author = new Author(1, "Maureen", "Johnson");
            Book book = new Book(1, "The Hand on the Wall", "Mysteries", 2020, 13.90M, 1, 2);
            Customer customer = new Customer(2, "456d", "Ivaylo", "Yordanov", 20);
            Seller seller = new Seller(1, "Maria", "Angelova");
            
            bookOperation.AddAuthor(author);
            bookOperation.CreateBook(book);
            bookOperation.AddCustomer(customer);
            bookOperation.AddSeller(seller);
            bookOperation.SellBook(1, 1, 1);

            Assert.AreEqual(1, this.dataConnection.Books.ToList().Count());           
        }

        [Test]
        public void GetAuthorTest()
        {
            BookOperation bookOperation = new BookOperation(dataConnection);

            Author author = new Author(1, "Maureen", "Johnson");
            bookOperation.AddAuthor(author);

            bookOperation.GetAuthor(1);

            Assert.AreEqual("Id:1 - Maureen Johnson", this.dataConnection.Authors.First().ToString());
        }

        [Test]
        public void GetBookTest()
        {
            BookOperation bookOperation = new BookOperation(dataConnection);

            Author author = new Author(1, "Maureen", "Johnson");
            Book book = new Book(1, "The Hand on the Wall", "Mysteries", 2020, 13.90M, 1, 2);

            bookOperation.AddAuthor(author);
            bookOperation.CreateBook(book);

            bookOperation.GetBook(1);

            Assert.AreEqual("Id: 1 Title: The Hand on the Wall  Genre: Mysteries Year: 2020  Price: 13.90  Stock: 2  AuthorId: 1",
                this.dataConnection.Books.First().ToString());
        }

        [Test]
        public void SaleBookWithoutLeftoversTest()
        {
            BookOperation bookOperation = new BookOperation(dataConnection);

            Author author = new Author(1, "Maureen", "Johnson");
            Book book = new Book(1, "The Hand on the Wall", "Mysteries", 2020, 13.90M, 1, 1);
            Customer customer = new Customer(2, "456d", "Ivaylo", "Yordanov", 20);
            Seller seller = new Seller(1, "Maria", "Angelova");

            bookOperation.AddAuthor(author);
            bookOperation.CreateBook(book);
            bookOperation.AddCustomer(customer);
            bookOperation.AddSeller(seller);
            bookOperation.SellBook(1, 1, 1);

            Assert.AreEqual(0, this.dataConnection.Books.ToList().Count());
        }


    }
}

